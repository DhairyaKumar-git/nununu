import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useActor } from './useActor';
import { type VideoMetadata, type UserProfile, ExternalBlob } from '../backend';

// ─── User Profile ────────────────────────────────────────────────────────────

export function useGetCallerUserProfile() {
  const { actor, isFetching: actorFetching } = useActor();

  const query = useQuery<UserProfile | null>({
    queryKey: ['currentUserProfile'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getCallerUserProfile();
    },
    enabled: !!actor && !actorFetching,
    retry: false,
  });

  return {
    ...query,
    isLoading: actorFetching || query.isLoading,
    isFetched: !!actor && query.isFetched,
  };
}

export function useSaveCallerUserProfile() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (profile: UserProfile) => {
      if (!actor) throw new Error('Actor not available');
      return actor.saveCallerUserProfile(profile);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentUserProfile'] });
    },
  });
}

// ─── Username ─────────────────────────────────────────────────────────────────

export function useGetUsername() {
  const { actor, isFetching: actorFetching } = useActor();

  const query = useQuery<string | null>({
    queryKey: ['username'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getUsername();
    },
    enabled: !!actor && !actorFetching,
    retry: false,
  });

  return {
    ...query,
    isLoading: actorFetching || query.isLoading,
    isFetched: !!actor && query.isFetched,
  };
}

export function useSetUsername() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (name: string) => {
      if (!actor) throw new Error('Actor not available');
      return actor.setUsername(name);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['username'] });
    },
  });
}

// ─── Admin Check ─────────────────────────────────────────────────────────────
// Checks both the role-based isCallerAdmin() AND the hardcoded-principal isAdmin().
// Returns true if either check passes, so the hardcoded admin principal always
// gets access even if the role-based system hasn't assigned them the admin role.

export function useIsCallerAdmin() {
  const { actor, isFetching: actorFetching } = useActor();

  const query = useQuery<boolean>({
    queryKey: ['isCallerAdmin'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');

      // Run both checks in parallel; return true if either succeeds
      const [roleBasedResult, hardcodedResult] = await Promise.allSettled([
        actor.isCallerAdmin(),
        actor.isAdmin(),
      ]);

      const isRoleAdmin =
        roleBasedResult.status === 'fulfilled' && roleBasedResult.value === true;
      const isHardcodedAdmin =
        hardcodedResult.status === 'fulfilled' && hardcodedResult.value === true;

      return isRoleAdmin || isHardcodedAdmin;
    },
    enabled: !!actor && !actorFetching,
    staleTime: 30_000,
    retry: false,
  });

  return {
    ...query,
    isLoading: actorFetching || query.isLoading,
    isFetched: !!actor && query.isFetched,
  };
}

// ─── Videos ──────────────────────────────────────────────────────────────────

export function useGetAllVideosMetadata() {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<VideoMetadata[]>({
    queryKey: ['allVideos'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getAllVideosMetadata();
    },
    enabled: !!actor && !actorFetching,
  });
}

export function useGetVideoMetadata(videoId: string) {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<VideoMetadata>({
    queryKey: ['videoMetadata', videoId],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getVideoMetadata(videoId);
    },
    enabled: !!actor && !actorFetching && !!videoId,
  });
}

export function useGetVideoChunks(videoId: string, enabled: boolean = true) {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<ExternalBlob[]>({
    queryKey: ['videoChunks', videoId],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getVideoChunks(videoId);
    },
    enabled: !!actor && !actorFetching && !!videoId && enabled,
    staleTime: 5 * 60 * 1000,
  });
}

export function useDeleteVideo() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (videoId: string) => {
      if (!actor) throw new Error('Actor not available');
      return actor.deleteVideo(videoId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['allVideos'] });
    },
  });
}

export function useUpdateVideoMetadata() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      videoId,
      title,
      description,
      category,
      thumbnailUrl,
    }: {
      videoId: string;
      title: string;
      description: string;
      category: string;
      thumbnailUrl: string;
    }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.updateVideoMetadata(videoId, title, description, category, thumbnailUrl);
    },
    onSuccess: (_data, { videoId }) => {
      queryClient.invalidateQueries({ queryKey: ['allVideos'] });
      queryClient.invalidateQueries({ queryKey: ['videoMetadata', videoId] });
    },
  });
}

// ─── Library ──────────────────────────────────────────────────────────────────

export function useGetMyLibrary() {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<string[]>({
    queryKey: ['myLibrary'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      try {
        return await actor.getMyLibrary();
      } catch {
        return [];
      }
    },
    enabled: !!actor && !actorFetching,
  });
}

export function useAddToLibrary() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (videoId: string) => {
      if (!actor) throw new Error('Actor not available');
      return actor.addToLibrary(videoId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['myLibrary'] });
    },
  });
}

export function useRemoveFromLibrary() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (videoId: string) => {
      if (!actor) throw new Error('Actor not available');
      return actor.removeFromLibrary(videoId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['myLibrary'] });
    },
  });
}

// ─── Upload helpers ───────────────────────────────────────────────────────────

// 512KB per chunk — safely within ICP's 2MB inter-canister message limit
const CHUNK_SIZE = 512 * 1024;

export interface UploadVideoParams {
  id: string;
  title: string;
  description: string;
  thumbnail: ExternalBlob;
  thumbnailUrl: string;
  category: string;
  /** The raw File object — chunks are read and uploaded one at a time to avoid OOM on large files */
  file: File;
  onProgress?: (pct: number) => void;
}

export function useUploadVideo() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      id,
      title,
      description,
      thumbnail,
      thumbnailUrl,
      category,
      file,
      onProgress,
    }: UploadVideoParams) => {
      if (!actor) throw new Error('Actor not available');

      const fileSize = file.size;
      const totalChunks = Math.ceil(fileSize / CHUNK_SIZE);
      const totalChunksBigInt = BigInt(totalChunks);

      /**
       * Read a single chunk from the File without loading the whole file.
       * This is critical for 2GB+ files — we read one 512KB slice at a time.
       */
      const readChunk = async (index: number): Promise<ExternalBlob> => {
        const start = index * CHUNK_SIZE;
        const end = Math.min(start + CHUNK_SIZE, fileSize);
        const slice = file.slice(start, end);
        const buffer = await slice.arrayBuffer();
        return ExternalBlob.fromBytes(new Uint8Array(buffer));
      };

      // Upload first chunk with metadata
      const firstChunk = await readChunk(0);
      await actor.uploadInitialVideoChunk(
        id,
        title,
        description,
        thumbnail,
        thumbnailUrl,
        category,
        totalChunksBigInt,
        BigInt(0),
        firstChunk
      );
      onProgress?.(Math.round((1 / totalChunks) * 100));

      // Upload remaining chunks sequentially, one at a time
      for (let i = 1; i < totalChunks; i++) {
        const chunk = await readChunk(i);
        await actor.uploadVideoChunk(id, BigInt(i), chunk);
        onProgress?.(Math.round(((i + 1) / totalChunks) * 100));
      }

      return id;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['allVideos'] });
    },
  });
}

// ─── Thumbnail ────────────────────────────────────────────────────────────────

export function useUpdateVideoThumbnail() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ videoId, thumbnailDataUrl }: { videoId: string; thumbnailDataUrl: string }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.updateVideoThumbnail(videoId, thumbnailDataUrl);
    },
    onSuccess: (_data, { videoId }) => {
      queryClient.invalidateQueries({ queryKey: ['allVideos'] });
      queryClient.invalidateQueries({ queryKey: ['videoMetadata', videoId] });
    },
  });
}
