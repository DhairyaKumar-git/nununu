/**
 * Deterministically derives a short 5-digit numeric user ID from a principal string.
 * The same principal always produces the same friendly ID.
 */
export function generateFriendlyUserId(principal: string): string {
  if (!principal) return 'User #00000';
  let hash = 0;
  for (let i = 0; i < principal.length; i++) {
    const char = principal.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash = hash & hash; // Convert to 32-bit integer
  }
  const positiveHash = Math.abs(hash);
  const shortId = String(positiveHash % 100000).padStart(5, '0');
  return `User #${shortId}`;
}
