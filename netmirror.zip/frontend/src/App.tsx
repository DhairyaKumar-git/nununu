import {
  createRouter,
  createRoute,
  createRootRoute,
  RouterProvider,
  Outlet,
} from '@tanstack/react-router';
import { useInternetIdentity } from './hooks/useInternetIdentity';
import { useIsCallerAdmin, useGetUsername } from './hooks/useQueries';
import { useActor } from './hooks/useActor';
import Navbar from './components/Navbar';
import LoginScreen from './components/LoginScreen';
import ProfileSetupModal from './components/ProfileSetupModal';
import ViewerHome from './pages/ViewerHome';
import VideoPlayer from './pages/VideoPlayer';
import AdminDashboard from './pages/AdminDashboard';
import MyLibrary from './pages/MyLibrary';
import ThumbnailSelection from './pages/ThumbnailSelection';
import { Toaster } from '@/components/ui/sonner';

// ─── Auth Guard Layout ────────────────────────────────────────────────────────

function AppLayout() {
  const { identity, isInitializing } = useInternetIdentity();
  const isAuthenticated = !!identity;
  const { data: username, isLoading: usernameLoading, isFetched: usernameFetched } = useGetUsername();

  // Suppress unused variable warning — actor is initialized here for side effects
  useActor();

  if (isInitializing) {
    return (
      <div className="min-h-screen bg-netflix-black flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <span className="text-3xl font-black text-netflix-red tracking-tight select-none">
            NetMirror
          </span>
          <div className="w-8 h-8 border-2 border-netflix-red border-t-transparent rounded-full animate-spin" />
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <LoginScreen />;
  }

  const showProfileSetup = isAuthenticated && !usernameLoading && usernameFetched && !username;

  return (
    <div className="min-h-screen bg-netflix-black text-white">
      <Navbar />
      {showProfileSetup && <ProfileSetupModal />}
      <Outlet />
      <Toaster theme="dark" />
    </div>
  );
}

// ─── Admin Guard ──────────────────────────────────────────────────────────────

function AdminGuard({ children }: { children: React.ReactNode }) {
  const { data: isAdmin, isLoading, isFetched } = useIsCallerAdmin();

  if (isLoading || !isFetched) {
    return (
      <div className="min-h-screen bg-netflix-black flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-8 h-8 border-2 border-netflix-red border-t-transparent rounded-full animate-spin" />
          <p className="text-netflix-grey text-sm">Checking permissions...</p>
        </div>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-netflix-black flex items-center justify-center">
        <div className="text-center">
          <div className="text-netflix-red text-6xl mb-4">🚫</div>
          <h1 className="text-2xl font-bold text-white mb-2">Access Denied</h1>
          <p className="text-netflix-grey">You don't have permission to access the admin dashboard.</p>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}

function AdminDashboardGuard() {
  return (
    <AdminGuard>
      <AdminDashboard />
    </AdminGuard>
  );
}

function ThumbnailSelectionGuard() {
  return (
    <AdminGuard>
      <ThumbnailSelection />
    </AdminGuard>
  );
}

// ─── Routes ───────────────────────────────────────────────────────────────────

const rootRoute = createRootRoute({
  component: AppLayout,
});

const homeRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/',
  component: ViewerHome,
});

const videoRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/video/$videoId',
  component: VideoPlayer,
});

const adminRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/admin',
  component: AdminDashboardGuard,
});

const thumbnailRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/admin/thumbnail/$videoId',
  component: ThumbnailSelectionGuard,
});

const libraryRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/library',
  component: MyLibrary,
});

const routeTree = rootRoute.addChildren([
  homeRoute,
  videoRoute,
  adminRoute,
  thumbnailRoute,
  libraryRoute,
]);

const router = createRouter({ routeTree });

declare module '@tanstack/react-router' {
  interface Register {
    router: typeof router;
  }
}

// ─── App ──────────────────────────────────────────────────────────────────────

export default function App() {
  return <RouterProvider router={router} />;
}
