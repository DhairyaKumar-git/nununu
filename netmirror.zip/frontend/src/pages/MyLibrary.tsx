import { useGetMyLibrary, useGetVideoMetadata, useRemoveFromLibrary } from '../hooks/useQueries';
import { useRouter } from '@tanstack/react-router';
import VideoCard from '../components/VideoCard';
import { Skeleton } from '@/components/ui/skeleton';
import { BookMarked, PlayCircle } from 'lucide-react';
import { toast } from 'sonner';
import { type VideoMetadata } from '../backend';

function LibraryVideoCard({ videoId, onRemove }: { videoId: string; onRemove: (id: string) => void }) {
  const { data: metadata, isLoading, error } = useGetVideoMetadata(videoId);

  if (isLoading) {
    return (
      <div className="flex-shrink-0 w-48 md:w-56">
        <Skeleton className="aspect-video rounded bg-netflix-dark w-full" />
        <Skeleton className="h-4 w-3/4 mt-2 bg-netflix-dark" />
        <Skeleton className="h-3 w-1/2 mt-1 bg-netflix-dark" />
      </div>
    );
  }

  if (error || !metadata) return null;

  return (
    <VideoCard
      video={metadata}
      showRemoveButton
      onRemove={onRemove}
    />
  );
}

export default function MyLibrary() {
  const router = useRouter();
  const { data: libraryIds, isLoading, error } = useGetMyLibrary();
  const removeFromLibrary = useRemoveFromLibrary();

  const handleRemove = async (videoId: string) => {
    try {
      await removeFromLibrary.mutateAsync(videoId);
      toast.success('Removed from your library');
    } catch {
      toast.error('Failed to remove video. Please try again.');
    }
  };

  return (
    <div className="min-h-screen bg-netflix-black pt-24 pb-16">
      {/* Header */}
      <div className="px-6 md:px-12 mb-8">
        <div className="flex items-center gap-3 mb-2">
          <BookMarked className="w-7 h-7 text-netflix-red" />
          <h1 className="text-3xl md:text-4xl font-black text-white">My Library</h1>
        </div>
        <p className="text-netflix-grey text-sm">Your saved videos, all in one place.</p>
      </div>

      {/* Content */}
      <div className="px-6 md:px-12">
        {isLoading ? (
          <div className="flex flex-wrap gap-4">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="flex-shrink-0 w-48 md:w-56">
                <Skeleton className="aspect-video rounded bg-netflix-dark w-full" />
                <Skeleton className="h-4 w-3/4 mt-2 bg-netflix-dark" />
                <Skeleton className="h-3 w-1/2 mt-1 bg-netflix-dark" />
              </div>
            ))}
          </div>
        ) : error ? (
          <div className="flex flex-col items-center justify-center py-24 text-center">
            <div className="text-netflix-red text-5xl mb-4">⚠️</div>
            <h2 className="text-xl font-bold text-white mb-2">Something went wrong</h2>
            <p className="text-netflix-grey">Could not load your library. Please try again later.</p>
          </div>
        ) : !libraryIds || libraryIds.length === 0 ? (
          /* Empty state */
          <div className="flex flex-col items-center justify-center py-24 text-center">
            <div className="w-20 h-20 bg-netflix-dark rounded-full flex items-center justify-center mb-6">
              <BookMarked className="w-10 h-10 text-netflix-grey" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-3">Your library is empty</h2>
            <p className="text-netflix-grey max-w-sm mb-8">
              Browse videos and save your favorites to watch them here anytime.
            </p>
            <button
              onClick={() => router.navigate({ to: '/' })}
              className="flex items-center gap-2 bg-netflix-red hover:bg-netflix-red-hover text-white font-semibold px-6 py-3 rounded transition-colors"
            >
              <PlayCircle className="w-5 h-5" />
              Browse Videos
            </button>
          </div>
        ) : (
          <div className="flex flex-wrap gap-6">
            {libraryIds.map((videoId) => (
              <LibraryVideoCard
                key={videoId}
                videoId={videoId}
                onRemove={handleRemove}
              />
            ))}
          </div>
        )}
      </div>

      {/* Footer */}
      <footer className="border-t border-netflix-dark/60 mt-16 py-8 px-8 md:px-12 text-center">
        <p className="text-netflix-grey text-sm">
          © {new Date().getFullYear()} NetMirror. Built with ❤️ using{' '}
          <a
            href={`https://caffeine.ai/?utm_source=Caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(window.location.hostname || 'netmirror')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="text-netflix-red hover:underline"
          >
            caffeine.ai
          </a>
        </p>
      </footer>
    </div>
  );
}
