import { Link } from '@tanstack/react-router';
import { useGetCallerUserProfile } from '../hooks/useQueries';
import VideoUploadForm from '../components/VideoUploadForm';
import VideoManagementList from '../components/VideoManagementList';
import { Home, Upload, List, Shield, Video } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useGetAllVideosMetadata } from '../hooks/useQueries';

export default function AdminDashboard() {
  const { data: userProfile } = useGetCallerUserProfile();
  const { data: videos } = useGetAllVideosMetadata();
  const videoCount = videos?.length ?? 0;

  return (
    <div className="min-h-screen bg-netflix-black pt-20 pb-16">
      <div className="max-w-5xl mx-auto px-6 md:px-8">
        {/* Header */}
        <div className="mb-8 bg-gradient-to-r from-netflix-red/10 to-transparent border border-netflix-red/20 rounded-2xl p-6">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 bg-netflix-red/20 rounded-xl flex items-center justify-center border border-netflix-red/30">
                <Shield className="w-7 h-7 text-netflix-red" />
              </div>
              <div>
                <div className="flex items-center gap-2 mb-0.5">
                  <h1 className="text-2xl md:text-3xl font-black text-white">Admin Dashboard</h1>
                  <span className="bg-netflix-red text-white text-xs font-bold px-2 py-0.5 rounded-full">
                    ADMIN
                  </span>
                </div>
                <p className="text-netflix-grey text-sm">
                  Welcome back,{' '}
                  <span className="text-netflix-light-grey font-semibold">
                    {userProfile?.name || 'Admin'}
                  </span>
                </p>
              </div>
            </div>

            {/* Stats */}
            <div className="flex items-center gap-3">
              <div className="bg-[#1f1f1f] border border-[#333] rounded-xl px-4 py-3 text-center min-w-[80px]">
                <div className="flex items-center justify-center gap-1.5 mb-0.5">
                  <Video className="w-4 h-4 text-netflix-red" />
                  <span className="text-2xl font-black text-white">{videoCount}</span>
                </div>
                <p className="text-netflix-grey text-xs">Videos</p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 mt-4 pt-4 border-t border-netflix-red/10">
            <Link
              to="/"
              className="flex items-center gap-1.5 text-netflix-grey hover:text-white transition-colors text-sm"
            >
              <Home className="w-4 h-4" />
              Back to Home
            </Link>
          </div>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="upload" className="w-full">
          <TabsList className="bg-[#1a1a1a] border border-[#2e2e2e] mb-6 w-full md:w-auto p-1 rounded-xl">
            <TabsTrigger
              value="upload"
              className="data-[state=active]:bg-netflix-red data-[state=active]:text-white data-[state=active]:shadow-md text-netflix-grey flex items-center gap-2 rounded-lg transition-all"
            >
              <Upload className="w-4 h-4" />
              Upload Video
            </TabsTrigger>
            <TabsTrigger
              value="manage"
              className="data-[state=active]:bg-netflix-red data-[state=active]:text-white data-[state=active]:shadow-md text-netflix-grey flex items-center gap-2 rounded-lg transition-all"
            >
              <List className="w-4 h-4" />
              Manage Videos
              {videoCount > 0 && (
                <span className="ml-1 bg-white/20 text-white text-xs font-bold px-1.5 py-0.5 rounded-full">
                  {videoCount}
                </span>
              )}
            </TabsTrigger>
          </TabsList>

          {/* Upload Tab */}
          <TabsContent value="upload">
            <div className="bg-[#1a1a1a] border border-[#2e2e2e] rounded-2xl p-6 md:p-8">
              <div className="mb-6 pb-5 border-b border-[#2e2e2e]">
                <div className="flex items-center gap-3 mb-1">
                  <div className="w-8 h-8 bg-netflix-red/20 rounded-lg flex items-center justify-center">
                    <Upload className="w-4 h-4 text-netflix-red" />
                  </div>
                  <h2 className="text-xl font-bold text-white">Upload New Video</h2>
                </div>
                <p className="text-netflix-grey text-sm ml-11">
                  Upload video files up to 2GB. Supported formats: MP4, MOV, AVI, MKV.
                </p>
              </div>
              <VideoUploadForm />
            </div>
          </TabsContent>

          {/* Manage Tab */}
          <TabsContent value="manage">
            <div className="bg-[#1a1a1a] border border-[#2e2e2e] rounded-2xl p-6 md:p-8">
              <div className="mb-6 pb-5 border-b border-[#2e2e2e]">
                <div className="flex items-center gap-3 mb-1">
                  <div className="w-8 h-8 bg-netflix-red/20 rounded-lg flex items-center justify-center">
                    <List className="w-4 h-4 text-netflix-red" />
                  </div>
                  <h2 className="text-xl font-bold text-white">Manage Videos</h2>
                </div>
                <p className="text-netflix-grey text-sm ml-11">
                  Edit metadata, set thumbnails, or delete uploaded videos.
                </p>
              </div>
              <VideoManagementList />
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Footer */}
      <footer className="border-t border-netflix-dark/60 py-8 px-8 md:px-12 text-center mt-16">
        <p className="text-netflix-grey text-sm">
          © {new Date().getFullYear()} NetMirror. Built with ❤️ using{' '}
          <a
            href={`https://caffeine.ai/?utm_source=Caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(window.location.hostname || 'netmirror')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="text-netflix-red hover:underline"
          >
            caffeine.ai
          </a>
        </p>
      </footer>
    </div>
  );
}
