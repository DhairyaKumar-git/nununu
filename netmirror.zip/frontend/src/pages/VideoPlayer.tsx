import { useState, useRef, useEffect } from 'react';
import { useParams, useRouter } from '@tanstack/react-router';
import {
  useGetVideoMetadata,
  useGetVideoChunks,
  useGetMyLibrary,
  useAddToLibrary,
  useRemoveFromLibrary,
} from '../hooks/useQueries';
import { ArrowLeft, Loader2, BookmarkPlus, BookmarkCheck } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';

export default function VideoPlayer() {
  const { videoId } = useParams({ from: '/video/$videoId' });
  const router = useRouter();
  const videoRef = useRef<HTMLVideoElement>(null);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [buildingUrl, setBuildingUrl] = useState(false);

  const { data: metadata, isLoading: metaLoading, error: metaError } = useGetVideoMetadata(videoId);
  const { data: chunks, isLoading: chunksLoading, error: chunksError } = useGetVideoChunks(videoId, !!videoId);
  const { data: libraryIds } = useGetMyLibrary();
  const addToLibrary = useAddToLibrary();
  const removeFromLibrary = useRemoveFromLibrary();

  const isInLibrary = libraryIds?.includes(videoId) ?? false;

  // Build a single blob URL from all chunks
  useEffect(() => {
    if (!chunks || chunks.length === 0) return;

    let cancelled = false;
    setBuildingUrl(true);

    (async () => {
      try {
        // If only one chunk, use direct URL for streaming
        if (chunks.length === 1) {
          const url = chunks[0].getDirectURL();
          if (!cancelled) {
            setVideoUrl(url);
            setBuildingUrl(false);
          }
          return;
        }

        // Multiple chunks: fetch bytes and concatenate into a single Blob
        const byteArrays = await Promise.all(chunks.map((c) => c.getBytes()));
        const totalLength = byteArrays.reduce((sum, arr) => sum + arr.length, 0);
        const combined = new Uint8Array(totalLength);
        let offset = 0;
        for (const arr of byteArrays) {
          combined.set(arr, offset);
          offset += arr.length;
        }
        const blob = new Blob([combined], { type: 'video/mp4' });
        const url = URL.createObjectURL(blob);
        if (!cancelled) {
          setVideoUrl(url);
          setBuildingUrl(false);
        }
      } catch (err) {
        if (!cancelled) setBuildingUrl(false);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [chunks]);

  // Cleanup blob URL on unmount
  useEffect(() => {
    return () => {
      if (videoUrl && videoUrl.startsWith('blob:')) {
        URL.revokeObjectURL(videoUrl);
      }
    };
  }, [videoUrl]);

  const handleLibraryToggle = async () => {
    try {
      if (isInLibrary) {
        await removeFromLibrary.mutateAsync(videoId);
        toast.success('Removed from your library');
      } else {
        await addToLibrary.mutateAsync(videoId);
        toast.success('Saved to your library');
      }
    } catch {
      toast.error('Failed to update library. Please try again.');
    }
  };

  const isLoading = metaLoading || chunksLoading || buildingUrl;
  const error = metaError || chunksError;
  const libraryPending = addToLibrary.isPending || removeFromLibrary.isPending;

  if (error) {
    return (
      <div className="pt-24 flex flex-col items-center justify-center min-h-[60vh] text-center px-6">
        <div className="text-netflix-red text-5xl mb-4">⚠️</div>
        <h2 className="text-2xl font-bold text-white mb-2">Video Not Found</h2>
        <p className="text-netflix-grey mb-6">This video could not be loaded.</p>
        <button
          onClick={() => router.navigate({ to: '/' })}
          className="bg-netflix-red hover:bg-netflix-red-hover text-white font-semibold px-6 py-2.5 rounded transition-colors"
        >
          Back to Home
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-netflix-black pt-16">
      {/* Back button */}
      <div className="px-6 md:px-12 py-4">
        <button
          onClick={() => router.navigate({ to: '/' })}
          className="flex items-center gap-2 text-netflix-light-grey hover:text-white transition-colors group"
        >
          <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
          <span className="text-sm font-medium">Back to Browse</span>
        </button>
      </div>

      {/* Video Player */}
      <div className="px-0 md:px-12 mb-8">
        <div className="relative bg-black aspect-video max-h-[75vh] mx-auto overflow-hidden md:rounded-lg shadow-2xl">
          {isLoading ? (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-netflix-darker">
              <Loader2 className="w-12 h-12 text-netflix-red animate-spin mb-3" />
              <p className="text-netflix-grey text-sm">
                {buildingUrl ? 'Preparing video...' : 'Loading...'}
              </p>
            </div>
          ) : videoUrl ? (
            <video
              ref={videoRef}
              src={videoUrl}
              className="w-full h-full object-contain"
              controls
              autoPlay={false}
              onEnded={() => {}}
            />
          ) : (
            <div className="absolute inset-0 flex items-center justify-center bg-netflix-darker">
              <p className="text-netflix-grey">Video unavailable</p>
            </div>
          )}
        </div>
      </div>

      {/* Video Info */}
      <div className="px-6 md:px-12 pb-16 max-w-4xl">
        {metaLoading ? (
          <div className="space-y-3">
            <Skeleton className="h-8 w-2/3 bg-netflix-dark" />
            <Skeleton className="h-5 w-1/4 bg-netflix-dark" />
            <Skeleton className="h-4 w-full bg-netflix-dark" />
            <Skeleton className="h-4 w-3/4 bg-netflix-dark" />
          </div>
        ) : metadata ? (
          <div className="animate-fade-in">
            <div className="flex items-start justify-between gap-4 mb-3">
              <h1 className="text-3xl md:text-4xl font-black text-white leading-tight">
                {metadata.title}
              </h1>
              <span className="flex-shrink-0 bg-netflix-red/20 text-netflix-red text-sm font-semibold px-3 py-1 rounded-full border border-netflix-red/30 mt-1">
                {metadata.category}
              </span>
            </div>
            <p className="text-netflix-grey text-sm mb-4">
              Uploaded{' '}
              {new Date(Number(metadata.uploadDate) / 1_000_000).toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'long',
                day: 'numeric',
              })}
            </p>

            {/* Library toggle button */}
            <button
              onClick={handleLibraryToggle}
              disabled={libraryPending}
              className={`flex items-center gap-2 px-5 py-2.5 rounded font-semibold text-sm transition-all mb-5 ${
                isInLibrary
                  ? 'bg-white/10 hover:bg-white/20 text-white border border-white/30'
                  : 'bg-netflix-red hover:bg-netflix-red-hover text-white'
              } disabled:opacity-60 disabled:cursor-not-allowed`}
            >
              {libraryPending ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : isInLibrary ? (
                <BookmarkCheck className="w-4 h-4" />
              ) : (
                <BookmarkPlus className="w-4 h-4" />
              )}
              {libraryPending
                ? 'Updating...'
                : isInLibrary
                ? 'Remove from Library'
                : 'Save to Library'}
            </button>

            {metadata.description && (
              <p className="text-netflix-light-grey text-base leading-relaxed">
                {metadata.description}
              </p>
            )}
          </div>
        ) : null}
      </div>

      {/* Footer */}
      <footer className="border-t border-netflix-dark/60 py-8 px-8 md:px-12 text-center">
        <p className="text-netflix-grey text-sm">
          © {new Date().getFullYear()} NetMirror. Built with ❤️ using{' '}
          <a
            href={`https://caffeine.ai/?utm_source=Caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(window.location.hostname || 'netmirror')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="text-netflix-red hover:underline"
          >
            caffeine.ai
          </a>
        </p>
      </footer>
    </div>
  );
}
