import { useState, useRef, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from '@tanstack/react-router';
import { useGetVideoChunks, useGetVideoMetadata, useUpdateVideoThumbnail } from '../hooks/useQueries';
import { Image, Camera, SkipForward, CheckCircle2, AlertCircle, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { toast } from 'sonner';

export default function ThumbnailSelection() {
  const { videoId } = useParams({ from: '/admin/thumbnail/$videoId' });
  const navigate = useNavigate();

  const { data: metadata, isLoading: metaLoading } = useGetVideoMetadata(videoId);
  const { data: chunks, isLoading: chunksLoading } = useGetVideoChunks(videoId);

  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [assemblingVideo, setAssemblingVideo] = useState(false);
  const [assembleError, setAssembleError] = useState<string | null>(null);
  const [capturedFrame, setCapturedFrame] = useState<string | null>(null);
  const [customImageDataUrl, setCustomImageDataUrl] = useState<string | null>(null);
  const [savingThumbnail, setSavingThumbnail] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);

  const updateThumbnail = useUpdateVideoThumbnail();

  // Assemble video blob from chunks when chunks are loaded
  useEffect(() => {
    if (!chunks || chunks.length === 0) return;

    let cancelled = false;
    setAssemblingVideo(true);
    setAssembleError(null);

    (async () => {
      try {
        const byteArrays: Uint8Array[] = [];
        for (const chunk of chunks) {
          if (cancelled) return;
          const bytes = await chunk.getBytes();
          byteArrays.push(bytes);
        }
        if (cancelled) return;

        const totalLength = byteArrays.reduce((sum, arr) => sum + arr.length, 0);
        const combined = new Uint8Array(totalLength);
        let offset = 0;
        for (const arr of byteArrays) {
          combined.set(arr, offset);
          offset += arr.length;
        }

        const blob = new Blob([combined], { type: 'video/mp4' });
        const url = URL.createObjectURL(blob);
        if (!cancelled) {
          setVideoUrl(url);
          setAssemblingVideo(false);
        }
      } catch (err) {
        if (!cancelled) {
          setAssembleError('Failed to load video for preview. You can still upload a custom thumbnail image.');
          setAssemblingVideo(false);
        }
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [chunks]);

  // Cleanup blob URL on unmount
  useEffect(() => {
    return () => {
      if (videoUrl) URL.revokeObjectURL(videoUrl);
    };
  }, [videoUrl]);

  const captureFrame = useCallback(() => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return;

    canvas.width = video.videoWidth || 1280;
    canvas.height = video.videoHeight || 720;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
    setCapturedFrame(dataUrl);
    setCustomImageDataUrl(null);
    toast.success('Frame captured! Click "Save Thumbnail" to apply it.');
  }, []);

  const handleCustomImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast.error('Please select a valid image file.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (ev) => {
      const result = ev.target?.result as string;
      setCustomImageDataUrl(result);
      setCapturedFrame(null);
    };
    reader.readAsDataURL(file);
  };

  const selectedThumbnail = capturedFrame ?? customImageDataUrl;

  const handleSaveThumbnail = async () => {
    if (!selectedThumbnail) return;
    setSavingThumbnail(true);
    try {
      await updateThumbnail.mutateAsync({ videoId, thumbnailDataUrl: selectedThumbnail });
      toast.success('Thumbnail saved successfully!');
      navigate({ to: '/admin' });
    } catch (err) {
      toast.error('Failed to save thumbnail. Please try again.');
      console.error('Thumbnail save error:', err);
    } finally {
      setSavingThumbnail(false);
    }
  };

  const handleSkip = () => {
    navigate({ to: '/admin' });
  };

  const isLoading = metaLoading || chunksLoading;

  return (
    <div className="min-h-screen bg-netflix-black pt-20 pb-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="flex items-center gap-3 mb-8">
          <button
            onClick={handleSkip}
            className="text-netflix-grey hover:text-white transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-white">Select Thumbnail</h1>
            {metadata && (
              <p className="text-netflix-grey text-sm mt-0.5">
                for <span className="text-netflix-light-grey font-medium">"{metadata.title}"</span>
              </p>
            )}
          </div>
        </div>

        {isLoading ? (
          <div className="flex flex-col items-center justify-center py-24 gap-4">
            <div className="w-10 h-10 border-2 border-netflix-red border-t-transparent rounded-full animate-spin" />
            <p className="text-netflix-grey">Loading video...</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Left: Video Player */}
            <div className="space-y-4">
              <h2 className="text-netflix-light-grey font-semibold text-sm uppercase tracking-wider">
                Capture from Video
              </h2>

              {assemblingVideo && (
                <div className="bg-[#1a1a1a] rounded-xl border border-[#333] p-6 text-center space-y-3">
                  <div className="w-8 h-8 border-2 border-netflix-red border-t-transparent rounded-full animate-spin mx-auto" />
                  <p className="text-netflix-grey text-sm">Assembling video preview...</p>
                  <Progress value={undefined} className="h-1 bg-[#333]" />
                </div>
              )}

              {assembleError && (
                <div className="bg-[#1a1a1a] rounded-xl border border-[#444] p-6 text-center space-y-2">
                  <AlertCircle className="w-8 h-8 text-netflix-grey mx-auto" />
                  <p className="text-netflix-grey text-sm">{assembleError}</p>
                </div>
              )}

              {videoUrl && !assemblingVideo && (
                <div className="space-y-3">
                  <div className="relative rounded-xl overflow-hidden bg-black border border-[#333]">
                    <video
                      ref={videoRef}
                      src={videoUrl}
                      controls
                      className="w-full aspect-video object-contain"
                      preload="metadata"
                    />
                  </div>
                  <Button
                    type="button"
                    onClick={captureFrame}
                    className="w-full bg-[#2a2a2a] hover:bg-[#333] text-white border border-[#444] hover:border-netflix-red/60 transition-all"
                  >
                    <Camera className="w-4 h-4 mr-2" />
                    Capture Current Frame
                  </Button>
                  <p className="text-netflix-grey text-xs text-center">
                    Pause the video at the desired frame, then click Capture
                  </p>
                </div>
              )}

              {/* Hidden canvas for frame capture */}
              <canvas ref={canvasRef} className="hidden" />
            </div>

            {/* Right: Custom Image Upload + Preview */}
            <div className="space-y-4">
              <h2 className="text-netflix-light-grey font-semibold text-sm uppercase tracking-wider">
                Upload Custom Image
              </h2>

              <div
                onClick={() => imageInputRef.current?.click()}
                className="border-2 border-dashed border-[#444] hover:border-netflix-red/60 hover:bg-netflix-red/5 rounded-xl p-8 text-center cursor-pointer transition-all duration-200"
              >
                <Image className="w-10 h-10 text-netflix-grey mx-auto mb-3" />
                <p className="text-white font-medium mb-1">Click to upload image</p>
                <p className="text-netflix-grey text-sm">JPG, PNG, WebP recommended</p>
              </div>

              <input
                ref={imageInputRef}
                type="file"
                accept="image/*"
                onChange={handleCustomImageChange}
                className="hidden"
              />

              {/* Thumbnail Preview */}
              {selectedThumbnail && (
                <div className="space-y-2">
                  <p className="text-netflix-light-grey text-sm font-medium">Preview</p>
                  <div className="relative rounded-xl overflow-hidden border border-netflix-red/40 bg-black">
                    <img
                      src={selectedThumbnail}
                      alt="Selected thumbnail"
                      className="w-full aspect-video object-cover"
                    />
                    <div className="absolute top-2 right-2 bg-netflix-red text-white text-xs px-2 py-0.5 rounded-full font-medium">
                      Selected
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Action Buttons */}
        {!isLoading && (
          <div className="flex flex-col sm:flex-row gap-3 mt-8 pt-6 border-t border-[#333]">
            <Button
              type="button"
              onClick={handleSaveThumbnail}
              disabled={!selectedThumbnail || savingThumbnail}
              className="flex-1 bg-netflix-red hover:bg-netflix-red-hover text-white font-bold py-3 disabled:opacity-50"
            >
              {savingThumbnail ? (
                <span className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Saving...
                </span>
              ) : (
                <span className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4" />
                  Save Thumbnail
                </span>
              )}
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={handleSkip}
              disabled={savingThumbnail}
              className="sm:w-40 border-[#444] text-netflix-grey hover:text-white hover:border-[#666] bg-transparent"
            >
              <SkipForward className="w-4 h-4 mr-2" />
              Skip for Now
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
