import { useMemo, useState } from 'react';
import { useGetAllVideosMetadata, useIsCallerAdmin } from '../hooks/useQueries';
import HeroBanner from '../components/HeroBanner';
import CategoryRow from '../components/CategoryRow';
import VideoCard from '../components/VideoCard';
import Navbar from '../components/Navbar';
import { Skeleton } from '@/components/ui/skeleton';
import { Film, Settings, SearchX } from 'lucide-react';
import { type VideoMetadata } from '../backend';
import { useRouter } from '@tanstack/react-router';

function LoadingSkeleton() {
  return (
    <div className="pt-16">
      {/* Hero skeleton */}
      <Skeleton className="w-full h-[70vh] min-h-[500px] bg-netflix-dark" />

      {/* Category rows skeleton */}
      <div className="mt-8 space-y-10 px-8 md:px-12">
        {[1, 2, 3].map((i) => (
          <div key={i}>
            <Skeleton className="h-7 w-48 bg-netflix-dark mb-4" />
            <div className="flex gap-3">
              {[1, 2, 3, 4, 5].map((j) => (
                <Skeleton key={j} className="flex-shrink-0 w-48 md:w-56 aspect-video bg-netflix-dark rounded" />
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function ViewerHome() {
  const { data: videos, isLoading, error } = useGetAllVideosMetadata();
  const { data: isAdmin, isFetched: isAdminFetched } = useIsCallerAdmin();
  const router = useRouter();
  const [searchQuery, setSearchQuery] = useState('');

  const showAdminButton = isAdminFetched && isAdmin === true;

  const { featuredVideo, categorizedVideos } = useMemo(() => {
    if (!videos || videos.length === 0) {
      return { featuredVideo: null, categorizedVideos: {} };
    }

    // Pick the most recently uploaded video as featured
    const sorted = [...videos].sort((a, b) =>
      Number(b.uploadDate) - Number(a.uploadDate)
    );
    const featured = sorted[0];

    // Group by category
    const byCategory: Record<string, VideoMetadata[]> = {};
    for (const video of videos) {
      const cat = video.category || 'Uncategorized';
      if (!byCategory[cat]) byCategory[cat] = [];
      byCategory[cat].push(video);
    }

    return { featuredVideo: featured, categorizedVideos: byCategory };
  }, [videos]);

  // Filter videos based on search query
  const filteredVideos = useMemo(() => {
    if (!searchQuery.trim() || !videos) return null;
    const q = searchQuery.toLowerCase().trim();
    return videos.filter(
      (v) =>
        v.title.toLowerCase().includes(q) ||
        v.category.toLowerCase().includes(q) ||
        v.description.toLowerCase().includes(q)
    );
  }, [searchQuery, videos]);

  const isSearching = searchQuery.trim().length > 0;

  if (isLoading) return <LoadingSkeleton />;

  if (error) {
    return (
      <div className="pt-24 flex flex-col items-center justify-center min-h-[60vh] text-center px-6">
        <div className="text-netflix-red text-5xl mb-4">⚠️</div>
        <h2 className="text-2xl font-bold text-white mb-2">Something went wrong</h2>
        <p className="text-netflix-grey">Failed to load videos. Please try again later.</p>
      </div>
    );
  }

  if (!videos || videos.length === 0) {
    return (
      <div className="pt-24 flex flex-col items-center justify-center min-h-[80vh] text-center px-6">
        <div className="w-24 h-24 bg-netflix-dark rounded-full flex items-center justify-center mb-6">
          <Film className="w-12 h-12 text-netflix-grey" />
        </div>
        <h2 className="text-3xl font-bold text-white mb-3">No Videos Yet</h2>
        <p className="text-netflix-grey text-lg max-w-md">
          The admin hasn't uploaded any videos yet. Check back soon for amazing content!
        </p>
        {showAdminButton && (
          <button
            onClick={() => router.navigate({ to: '/admin' })}
            className="mt-8 flex items-center gap-2 bg-netflix-red hover:bg-netflix-red/90 text-white font-semibold px-6 py-3 rounded transition-colors"
          >
            <Settings className="w-5 h-5" />
            Go to Admin Dashboard
          </button>
        )}
      </div>
    );
  }

  const categoryEntries = Object.entries(categorizedVideos);

  return (
    <div className="min-h-screen bg-netflix-black">
      {/* Navbar with search */}
      <Navbar onSearch={setSearchQuery} searchQuery={searchQuery} />

      {/* Admin Dashboard shortcut — only visible to admin */}
      {showAdminButton && (
        <div className="fixed bottom-6 right-6 z-40">
          <button
            onClick={() => router.navigate({ to: '/admin' })}
            className="flex items-center gap-2 bg-netflix-red hover:bg-netflix-red/90 text-white font-semibold px-5 py-3 rounded-full shadow-lg transition-all hover:scale-105 active:scale-95"
            title="Admin Dashboard"
          >
            <Settings className="w-5 h-5" />
            <span className="hidden sm:inline">Admin Dashboard</span>
          </button>
        </div>
      )}

      {/* Search Results */}
      {isSearching ? (
        <div className="pt-24 pb-16 px-8 md:px-12">
          <div className="mb-6">
            <h2 className="text-2xl font-bold text-white">
              Search results for{' '}
              <span className="text-netflix-red">"{searchQuery}"</span>
            </h2>
            <p className="text-netflix-grey text-sm mt-1">
              {filteredVideos?.length ?? 0} video{filteredVideos?.length !== 1 ? 's' : ''} found
            </p>
          </div>

          {filteredVideos && filteredVideos.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3">
              {filteredVideos.map((video) => (
                <VideoCard key={video.id} video={video} />
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-24 text-center">
              <div className="w-20 h-20 bg-netflix-dark rounded-full flex items-center justify-center mb-5">
                <SearchX className="w-10 h-10 text-netflix-grey" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">No results found</h3>
              <p className="text-netflix-grey max-w-sm">
                No videos match "<span className="text-netflix-light-grey">{searchQuery}</span>". Try a different title or category.
              </p>
            </div>
          )}
        </div>
      ) : (
        <>
          {/* Hero Banner */}
          {featuredVideo && <HeroBanner video={featuredVideo} />}

          {/* Category Rows */}
          <div className="relative z-10 -mt-8 pb-16">
            {/* All Videos row */}
            <CategoryRow category="All Videos" videos={videos} />

            {/* Per-category rows (only if more than one category) */}
            {categoryEntries.length > 1 &&
              categoryEntries.map(([category, catVideos]) => (
                <CategoryRow key={category} category={category} videos={catVideos} />
              ))}
          </div>
        </>
      )}

      {/* Footer */}
      <footer className="border-t border-netflix-dark/60 py-8 px-8 md:px-12 text-center">
        <p className="text-netflix-grey text-sm">
          © {new Date().getFullYear()} NetMirror. Built with ❤️ using{' '}
          <a
            href={`https://caffeine.ai/?utm_source=Caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(window.location.hostname || 'netmirror')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="text-netflix-red hover:underline"
          >
            caffeine.ai
          </a>
        </p>
      </footer>
    </div>
  );
}
