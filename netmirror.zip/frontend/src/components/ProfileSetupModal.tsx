import { useState, useEffect } from 'react';
import { useSetUsername, useGetUsername } from '../hooks/useQueries';
import { User } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

export default function ProfileSetupModal() {
  const [name, setName] = useState('');
  const [open, setOpen] = useState(true);
  const setUsername = useSetUsername();
  const { data: existingUsername, isFetched: usernameFetched } = useGetUsername();

  // Pre-fill if username already exists
  useEffect(() => {
    if (usernameFetched && existingUsername) {
      setName(existingUsername);
    }
  }, [usernameFetched, existingUsername]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    try {
      await setUsername.mutateAsync(name.trim());
      setOpen(false);
      toast.success('Welcome to NetMirror!');
    } catch (err) {
      toast.error('Failed to save username. Please try again.');
    }
  };

  return (
    <Dialog open={open} onOpenChange={() => {}}>
      <DialogContent
        className="bg-netflix-dark border-netflix-dark/60 text-white max-w-md"
        onInteractOutside={(e) => e.preventDefault()}
      >
        <DialogHeader>
          <div className="flex items-center gap-3 mb-2">
            <div className="w-12 h-12 bg-netflix-red/20 rounded-full flex items-center justify-center">
              <User className="w-6 h-6 text-netflix-red" />
            </div>
            <div>
              <DialogTitle className="text-white text-xl">Welcome to NetMirror!</DialogTitle>
              <DialogDescription className="text-netflix-grey">
                Choose a username to get started.
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 mt-2">
          <div className="space-y-2">
            <Label htmlFor="username" className="text-netflix-light-grey font-medium">
              Your Username
            </Label>
            <Input
              id="username"
              type="text"
              placeholder="Enter your username"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="bg-[#333] border-[#555] text-white placeholder:text-netflix-grey focus:border-netflix-red focus:ring-netflix-red"
              autoFocus
              required
              maxLength={32}
            />
            <p className="text-netflix-grey text-xs">
              This is how you'll appear on NetMirror. You can change it later.
            </p>
          </div>

          <Button
            type="submit"
            disabled={!name.trim() || setUsername.isPending}
            className="w-full bg-netflix-red hover:bg-netflix-red-hover text-white font-semibold py-2.5 rounded transition-all"
          >
            {setUsername.isPending ? (
              <span className="flex items-center gap-2">
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Saving...
              </span>
            ) : (
              'Continue to NetMirror'
            )}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
