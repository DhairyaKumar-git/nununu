import { Play, Info } from 'lucide-react';
import { useRouter } from '@tanstack/react-router';
import { type VideoMetadata } from '../backend';

interface HeroBannerProps {
  video: VideoMetadata;
}

export default function HeroBanner({ video }: HeroBannerProps) {
  const router = useRouter();
  const thumbnailUrl = video.thumbnail.getDirectURL();

  return (
    <div className="relative w-full h-[70vh] min-h-[500px] overflow-hidden">
      {/* Background image */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: thumbnailUrl
            ? `url('${thumbnailUrl}')`
            : `url('/assets/generated/hero-banner.dim_1920x600.png')`,
        }}
      />

      {/* Gradient overlays */}
      <div className="absolute inset-0 hero-gradient" />
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-netflix-black to-transparent" />

      {/* Content */}
      <div className="absolute inset-0 flex flex-col justify-end pb-16 px-8 md:px-16 max-w-3xl">
        <div className="animate-fade-in">
          <h1 className="text-4xl md:text-6xl font-black text-white mb-3 leading-tight drop-shadow-lg">
            {video.title}
          </h1>
          <p className="text-sm md:text-base text-netflix-light-grey mb-6 line-clamp-3 max-w-xl leading-relaxed">
            {video.description}
          </p>
          <div className="flex items-center gap-3">
            <button
              onClick={() => router.navigate({ to: '/video/$videoId', params: { videoId: video.id } })}
              className="flex items-center gap-2 bg-white text-black font-bold px-6 py-3 rounded hover:bg-white/80 transition-all duration-200 text-sm md:text-base"
            >
              <Play className="w-5 h-5 fill-black" />
              Play
            </button>
            <button
              onClick={() => router.navigate({ to: '/video/$videoId', params: { videoId: video.id } })}
              className="flex items-center gap-2 bg-netflix-grey/40 text-white font-semibold px-6 py-3 rounded hover:bg-netflix-grey/60 transition-all duration-200 text-sm md:text-base backdrop-blur-sm"
            >
              <Info className="w-5 h-5" />
              More Info
            </button>
          </div>
        </div>
      </div>

      {/* Category badge */}
      <div className="absolute top-24 right-8 md:right-16">
        <span className="bg-netflix-red/80 text-white text-xs font-semibold px-3 py-1.5 rounded-full backdrop-blur-sm">
          {video.category}
        </span>
      </div>
    </div>
  );
}
