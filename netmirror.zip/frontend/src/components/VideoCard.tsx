import { useState } from 'react';
import { useRouter } from '@tanstack/react-router';
import { Play, Info, Trash2 } from 'lucide-react';
import { type VideoMetadata } from '../backend';

interface VideoCardProps {
  video: VideoMetadata;
  showRemoveButton?: boolean;
  onRemove?: (videoId: string) => void;
}

export default function VideoCard({ video, showRemoveButton = false, onRemove }: VideoCardProps) {
  const router = useRouter();
  const [imgError, setImgError] = useState(false);
  const thumbnailUrl = !imgError ? video.thumbnail.getDirectURL() : null;

  const handleClick = () => {
    router.navigate({ to: '/video/$videoId', params: { videoId: video.id } });
  };

  const uploadDate = new Date(Number(video.uploadDate) / 1_000_000);
  const formattedDate = uploadDate.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
  });

  return (
    <div
      className="relative flex-shrink-0 w-48 md:w-56 cursor-pointer group"
      onClick={handleClick}
    >
      {/* Thumbnail */}
      <div className="relative aspect-video rounded overflow-hidden bg-netflix-dark">
        <img
          src={thumbnailUrl || '/assets/generated/thumbnail-placeholder.dim_400x225.png'}
          alt={video.title}
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
          onError={() => setImgError(true)}
        />

        {/* Hover overlay */}
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-all duration-300 flex items-center justify-center">
          <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center gap-2">
            <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-lg">
              <Play className="w-5 h-5 fill-black text-black ml-0.5" />
            </div>
            {showRemoveButton && onRemove && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onRemove(video.id);
                }}
                className="w-10 h-10 bg-netflix-red rounded-full flex items-center justify-center shadow-lg hover:bg-netflix-red-hover transition-colors"
                title="Remove from library"
              >
                <Trash2 className="w-4 h-4 text-white" />
              </button>
            )}
          </div>
        </div>

        {/* Red border on hover */}
        <div className="absolute inset-0 border-2 border-transparent group-hover:border-netflix-red rounded transition-all duration-300" />
      </div>

      {/* Info panel - appears on hover */}
      <div className="absolute left-0 right-0 top-full z-20 bg-netflix-dark rounded-b-lg shadow-card opacity-0 group-hover:opacity-100 transition-all duration-300 translate-y-0 group-hover:translate-y-0 pointer-events-none group-hover:pointer-events-auto">
        <div className="p-3">
          <div className="flex items-center justify-between mb-1.5">
            <button
              onClick={(e) => { e.stopPropagation(); handleClick(); }}
              className="w-8 h-8 bg-white rounded-full flex items-center justify-center hover:bg-white/80 transition-colors"
            >
              <Play className="w-4 h-4 fill-black text-black ml-0.5" />
            </button>
            <div className="flex items-center gap-1.5">
              {showRemoveButton && onRemove && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onRemove(video.id);
                  }}
                  className="w-8 h-8 bg-netflix-red/20 rounded-full flex items-center justify-center hover:bg-netflix-red/40 transition-colors"
                  title="Remove from library"
                >
                  <Trash2 className="w-3.5 h-3.5 text-netflix-red" />
                </button>
              )}
              <button
                onClick={(e) => { e.stopPropagation(); handleClick(); }}
                className="w-8 h-8 bg-[#333] rounded-full flex items-center justify-center hover:bg-[#444] transition-colors"
              >
                <Info className="w-4 h-4 text-white" />
              </button>
            </div>
          </div>
          <h3 className="text-white text-sm font-semibold truncate">{video.title}</h3>
          <div className="flex items-center gap-2 mt-1">
            <span className="text-netflix-red text-xs font-medium">{video.category}</span>
            <span className="text-netflix-grey text-xs">{formattedDate}</span>
          </div>
          {video.description && (
            <p className="text-netflix-grey text-xs mt-1.5 line-clamp-2 leading-relaxed">
              {video.description}
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
