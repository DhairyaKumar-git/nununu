import { useRef } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { type VideoMetadata } from '../backend';
import VideoCard from './VideoCard';

interface CategoryRowProps {
  category: string;
  videos: VideoMetadata[];
}

export default function CategoryRow({ category, videos }: CategoryRowProps) {
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: 'left' | 'right') => {
    if (!scrollRef.current) return;
    const amount = 400;
    scrollRef.current.scrollBy({
      left: direction === 'left' ? -amount : amount,
      behavior: 'smooth',
    });
  };

  if (videos.length === 0) return null;

  return (
    <div className="mb-10 group/row">
      <h2 className="text-white text-xl md:text-2xl font-bold mb-4 px-8 md:px-12">
        {category}
      </h2>

      <div className="relative px-8 md:px-12">
        {/* Left scroll button */}
        <button
          onClick={() => scroll('left')}
          className="absolute left-0 top-1/2 -translate-y-1/2 z-10 w-10 h-full bg-gradient-to-r from-netflix-black/80 to-transparent flex items-center justify-start pl-1 opacity-0 group-hover/row:opacity-100 transition-opacity duration-200"
          aria-label="Scroll left"
        >
          <div className="w-8 h-8 bg-black/60 rounded-full flex items-center justify-center hover:bg-black/80 transition-colors">
            <ChevronLeft className="w-5 h-5 text-white" />
          </div>
        </button>

        {/* Video cards */}
        <div
          ref={scrollRef}
          className="flex gap-3 overflow-x-auto pb-4 category-scroll"
          style={{ scrollbarWidth: 'none' }}
        >
          {videos.map((video) => (
            <VideoCard key={video.id} video={video} />
          ))}
        </div>

        {/* Right scroll button */}
        <button
          onClick={() => scroll('right')}
          className="absolute right-0 top-1/2 -translate-y-1/2 z-10 w-10 h-full bg-gradient-to-l from-netflix-black/80 to-transparent flex items-center justify-end pr-1 opacity-0 group-hover/row:opacity-100 transition-opacity duration-200"
          aria-label="Scroll right"
        >
          <div className="w-8 h-8 bg-black/60 rounded-full flex items-center justify-center hover:bg-black/80 transition-colors">
            <ChevronRight className="w-5 h-5 text-white" />
          </div>
        </button>
      </div>
    </div>
  );
}
