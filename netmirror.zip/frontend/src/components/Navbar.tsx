import { useState, useEffect } from 'react';
import { Link, useRouter } from '@tanstack/react-router';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { useQueryClient } from '@tanstack/react-query';
import { useGetUsername, useIsCallerAdmin } from '../hooks/useQueries';
import { LogOut, Settings, Home, ChevronDown, BookMarked, Copy, Check, Search, X } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { generateFriendlyUserId } from '../utils/principalUtils';

interface NavbarProps {
  onSearch?: (query: string) => void;
  searchQuery?: string;
}

export default function Navbar({ onSearch, searchQuery = '' }: NavbarProps) {
  const { clear, identity } = useInternetIdentity();
  const queryClient = useQueryClient();
  const { data: username } = useGetUsername();
  const { data: isAdmin, isLoading: isAdminLoading, isFetched: isAdminFetched } = useIsCallerAdmin();
  const [scrolled, setScrolled] = useState(false);
  const [copied, setCopied] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [localSearch, setLocalSearch] = useState(searchQuery);
  const router = useRouter();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setLocalSearch(searchQuery);
  }, [searchQuery]);

  const handleLogout = async () => {
    await clear();
    queryClient.clear();
  };

  const principalId = identity?.getPrincipal().toString() ?? '';
  const friendlyUserId = generateFriendlyUserId(principalId);

  const handleCopyPrincipal = () => {
    if (principalId) {
      navigator.clipboard.writeText(principalId).then(() => {
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      });
    }
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch?.(localSearch);
  };

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setLocalSearch(e.target.value);
    onSearch?.(e.target.value);
  };

  const handleClearSearch = () => {
    setLocalSearch('');
    onSearch?.('');
    setSearchOpen(false);
  };

  const displayName = username || friendlyUserId;
  const initials = username
    ? username.split(' ').map((n) => n[0]).join('').toUpperCase().slice(0, 2)
    : friendlyUserId.replace('User #', '').slice(0, 2);

  // Only show admin UI once the check has completed and returned true
  const showAdmin = isAdminFetched && isAdmin === true;
  // Only show library link once the check has completed and user is not admin
  const showLibrary = isAdminFetched && !isAdmin;

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-netflix-black/95 backdrop-blur-sm shadow-lg'
          : 'bg-gradient-to-b from-black/80 to-transparent'
      }`}
    >
      <div className="flex items-center justify-between px-6 md:px-12 py-4">
        {/* Logo */}
        <div className="flex items-center gap-8">
          <Link to="/">
            <span
              aria-label="NetMirror"
              className="text-2xl md:text-3xl font-black text-netflix-red tracking-tight cursor-pointer select-none"
            >
              NetMirror
            </span>
          </Link>

          {/* Nav Links */}
          <div className="hidden md:flex items-center gap-6">
            <Link
              to="/"
              className="text-netflix-light-grey hover:text-white transition-colors text-sm font-medium flex items-center gap-1.5"
              activeProps={{ className: 'text-white font-semibold' }}
            >
              <Home className="w-4 h-4" />
              Home
            </Link>
            {showLibrary && (
              <Link
                to="/library"
                className="text-netflix-light-grey hover:text-white transition-colors text-sm font-medium flex items-center gap-1.5"
                activeProps={{ className: 'text-white font-semibold' }}
              >
                <BookMarked className="w-4 h-4" />
                My Library
              </Link>
            )}
            {showAdmin && (
              <Link
                to="/admin"
                className="text-netflix-light-grey hover:text-white transition-colors text-sm font-medium flex items-center gap-1.5"
                activeProps={{ className: 'text-white font-semibold' }}
              >
                <Settings className="w-4 h-4" />
                Admin Dashboard
              </Link>
            )}
          </div>
        </div>

        {/* Right side */}
        <div className="flex items-center gap-3">
          {/* Search */}
          {onSearch && (
            <div className="flex items-center">
              {searchOpen ? (
                <form onSubmit={handleSearchSubmit} className="flex items-center gap-2">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-netflix-grey pointer-events-none" />
                    <input
                      autoFocus
                      type="text"
                      value={localSearch}
                      onChange={handleSearchChange}
                      placeholder="Search titles, categories..."
                      className="bg-netflix-dark/90 border border-[#444] text-white placeholder:text-netflix-grey text-sm rounded-full pl-9 pr-9 py-2 w-56 md:w-72 focus:outline-none focus:border-netflix-red transition-colors"
                    />
                    {localSearch && (
                      <button
                        type="button"
                        onClick={handleClearSearch}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-netflix-grey hover:text-white transition-colors"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                  <button
                    type="button"
                    onClick={() => { setSearchOpen(false); if (!localSearch) onSearch?.(''); }}
                    className="text-netflix-grey hover:text-white transition-colors p-1"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </form>
              ) : (
                <button
                  onClick={() => setSearchOpen(true)}
                  className="text-netflix-light-grey hover:text-white transition-colors p-2 rounded-full hover:bg-white/10"
                  aria-label="Search"
                >
                  <Search className="w-5 h-5" />
                </button>
              )}
            </div>
          )}

          {showAdmin && (
            <span className="hidden md:inline-flex items-center gap-1 bg-netflix-red/20 text-netflix-red text-xs font-semibold px-2.5 py-1 rounded-full border border-netflix-red/30">
              <Settings className="w-3 h-3" />
              Admin
            </span>
          )}
          {isAdminLoading && (
            <div className="w-4 h-4 border-2 border-netflix-red border-t-transparent rounded-full animate-spin" />
          )}

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="flex items-center gap-2 group outline-none">
                <div className="w-8 h-8 bg-netflix-red rounded flex items-center justify-center text-white text-sm font-bold">
                  {initials}
                </div>
                <span className="hidden md:block text-white text-sm font-medium max-w-[120px] truncate">
                  {displayName}
                </span>
                <ChevronDown className="w-4 h-4 text-netflix-grey group-hover:text-white transition-colors" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent
              align="end"
              className="bg-netflix-dark border-[#333] text-white min-w-[260px]"
            >
              <div className="px-3 py-2 border-b border-[#333]">
                <p className="text-sm font-semibold text-white truncate">{displayName}</p>
                {/* Friendly User ID with copy button */}
                <div className="mt-1.5">
                  <p className="text-xs text-netflix-grey mb-1">User ID:</p>
                  <div className="flex items-center gap-1.5">
                    <p className="text-xs text-netflix-light-grey font-mono flex-1">
                      {friendlyUserId}
                    </p>
                    <button
                      onClick={handleCopyPrincipal}
                      className="flex-shrink-0 text-netflix-grey hover:text-white transition-colors"
                      title="Copy full principal ID"
                    >
                      {copied ? (
                        <Check className="w-3.5 h-3.5 text-green-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>
                </div>
              </div>
              <DropdownMenuItem
                onClick={() => router.navigate({ to: '/' })}
                className="text-netflix-light-grey hover:text-white hover:bg-[#333] cursor-pointer"
              >
                <Home className="w-4 h-4 mr-2" />
                Home
              </DropdownMenuItem>
              {showLibrary && (
                <DropdownMenuItem
                  onClick={() => router.navigate({ to: '/library' })}
                  className="text-netflix-light-grey hover:text-white hover:bg-[#333] cursor-pointer"
                >
                  <BookMarked className="w-4 h-4 mr-2" />
                  My Library
                </DropdownMenuItem>
              )}
              {showAdmin && (
                <DropdownMenuItem
                  onClick={() => router.navigate({ to: '/admin' })}
                  className="text-netflix-light-grey hover:text-white hover:bg-[#333] cursor-pointer"
                >
                  <Settings className="w-4 h-4 mr-2" />
                  Admin Dashboard
                </DropdownMenuItem>
              )}
              <DropdownMenuSeparator className="bg-[#333]" />
              <DropdownMenuItem
                onClick={handleLogout}
                className="text-netflix-red hover:text-netflix-red hover:bg-netflix-red/10 cursor-pointer"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Sign Out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </nav>
  );
}
