import { useState } from 'react';
import { useNavigate } from '@tanstack/react-router';
import { useGetAllVideosMetadata, useDeleteVideo, useUpdateVideoMetadata } from '../hooks/useQueries';
import { Trash2, Film, Calendar, Tag, Loader2, AlertCircle, Pencil, Image, X, Check } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogClose,
} from '@/components/ui/dialog';
import { toast } from 'sonner';
import { type VideoMetadata } from '../backend';

const CATEGORIES = [
  'Action', 'Comedy', 'Drama', 'Horror', 'Sci-Fi',
  'Documentary', 'Animation', 'Thriller', 'Romance', 'Other'
];

interface EditFormState {
  title: string;
  description: string;
  category: string;
  thumbnailUrl: string;
}

export default function VideoManagementList() {
  const { data: videos, isLoading, error } = useGetAllVideosMetadata();
  const deleteVideo = useDeleteVideo();
  const updateMetadata = useUpdateVideoMetadata();
  const navigate = useNavigate();
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [editingVideo, setEditingVideo] = useState<VideoMetadata | null>(null);
  const [editForm, setEditForm] = useState<EditFormState>({
    title: '',
    description: '',
    category: 'Other',
    thumbnailUrl: '',
  });

  const handleDelete = async (videoId: string, title: string) => {
    setDeletingId(videoId);
    try {
      await deleteVideo.mutateAsync(videoId);
      toast.success(`"${title}" deleted successfully.`);
    } catch (err) {
      toast.error('Failed to delete video. Please try again.');
    } finally {
      setDeletingId(null);
    }
  };

  const openEdit = (video: VideoMetadata) => {
    setEditingVideo(video);
    setEditForm({
      title: video.title,
      description: video.description,
      category: video.category,
      thumbnailUrl: video.thumbnailUrl,
    });
  };

  const closeEdit = () => {
    setEditingVideo(null);
  };

  const handleSaveEdit = async () => {
    if (!editingVideo) return;
    try {
      await updateMetadata.mutateAsync({
        videoId: editingVideo.id,
        title: editForm.title.trim(),
        description: editForm.description.trim(),
        category: editForm.category,
        thumbnailUrl: editForm.thumbnailUrl.trim(),
      });
      toast.success(`"${editForm.title}" updated successfully.`);
      closeEdit();
    } catch (err) {
      toast.error('Failed to update video. Please try again.');
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-3">
        {[1, 2, 3].map((i) => (
          <Skeleton key={i} className="h-24 bg-[#2a2a2a] rounded-lg" />
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center gap-3 text-netflix-red bg-netflix-red/10 border border-netflix-red/20 rounded-lg p-4">
        <AlertCircle className="w-5 h-5 flex-shrink-0" />
        <p className="text-sm">Failed to load videos.</p>
      </div>
    );
  }

  if (!videos || videos.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="w-16 h-16 bg-[#2a2a2a] rounded-full flex items-center justify-center mx-auto mb-4">
          <Film className="w-8 h-8 text-netflix-grey" />
        </div>
        <p className="text-netflix-grey text-base">No videos uploaded yet.</p>
        <p className="text-netflix-grey/60 text-sm mt-1">Use the Upload tab to add your first video.</p>
      </div>
    );
  }

  return (
    <>
      <div className="space-y-3">
        {videos.map((video) => {
          const thumbnailSrc = video.thumbnailUrl || video.thumbnail.getDirectURL();
          const uploadDate = new Date(Number(video.uploadDate) / 1_000_000);
          const isDeleting = deletingId === video.id;

          return (
            <div
              key={video.id}
              className={`flex items-center gap-4 bg-[#1a1a1a] border border-[#2e2e2e] rounded-xl p-3 transition-all duration-200 ${
                isDeleting ? 'opacity-50' : 'hover:border-[#444]'
              }`}
            >
              {/* Thumbnail */}
              <div className="flex-shrink-0 w-24 h-14 rounded-lg overflow-hidden bg-netflix-dark">
                <img
                  src={thumbnailSrc || '/assets/generated/thumbnail-placeholder.dim_400x225.png'}
                  alt={video.title}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = '/assets/generated/thumbnail-placeholder.dim_400x225.png';
                  }}
                />
              </div>

              {/* Info */}
              <div className="flex-1 min-w-0">
                <h4 className="text-white font-semibold text-sm truncate">{video.title}</h4>
                <div className="flex items-center gap-3 mt-1 flex-wrap">
                  <span className="flex items-center gap-1 text-netflix-grey text-xs">
                    <Tag className="w-3 h-3" />
                    {video.category}
                  </span>
                  <span className="flex items-center gap-1 text-netflix-grey text-xs">
                    <Calendar className="w-3 h-3" />
                    {uploadDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                  </span>
                </div>
                {video.description && (
                  <p className="text-netflix-grey/60 text-xs mt-1 truncate">{video.description}</p>
                )}
              </div>

              {/* Action buttons */}
              <div className="flex items-center gap-2 flex-shrink-0">
                {/* Edit button */}
                <button
                  onClick={() => openEdit(video)}
                  disabled={isDeleting}
                  className="w-9 h-9 bg-blue-500/10 hover:bg-blue-500/20 border border-blue-500/20 hover:border-blue-500/40 text-blue-400 rounded-lg flex items-center justify-center transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                  aria-label={`Edit ${video.title}`}
                  title="Edit video"
                >
                  <Pencil className="w-4 h-4" />
                </button>

                {/* Set Thumbnail button */}
                <button
                  onClick={() => navigate({ to: '/admin/thumbnail/$videoId', params: { videoId: video.id } })}
                  disabled={isDeleting}
                  className="w-9 h-9 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/20 hover:border-amber-500/40 text-amber-400 rounded-lg flex items-center justify-center transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                  aria-label={`Set thumbnail for ${video.title}`}
                  title="Set thumbnail"
                >
                  <Image className="w-4 h-4" />
                </button>

                {/* Delete button */}
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <button
                      disabled={isDeleting}
                      className="w-9 h-9 bg-netflix-red/10 hover:bg-netflix-red/20 border border-netflix-red/20 hover:border-netflix-red/40 text-netflix-red rounded-lg flex items-center justify-center transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                      aria-label={`Delete ${video.title}`}
                      title="Delete video"
                    >
                      {isDeleting ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <Trash2 className="w-4 h-4" />
                      )}
                    </button>
                  </AlertDialogTrigger>
                  <AlertDialogContent className="bg-netflix-dark border-[#444] text-white">
                    <AlertDialogHeader>
                      <AlertDialogTitle className="text-white">Delete Video</AlertDialogTitle>
                      <AlertDialogDescription className="text-netflix-grey">
                        Are you sure you want to delete <strong className="text-white">"{video.title}"</strong>?
                        This action cannot be undone.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel className="bg-[#333] border-[#555] text-white hover:bg-[#444]">
                        Cancel
                      </AlertDialogCancel>
                      <AlertDialogAction
                        onClick={() => handleDelete(video.id, video.title)}
                        className="bg-netflix-red hover:bg-netflix-red-hover text-white border-0"
                      >
                        Delete
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            </div>
          );
        })}
      </div>

      {/* Edit Video Dialog */}
      <Dialog open={!!editingVideo} onOpenChange={(open) => { if (!open) closeEdit(); }}>
        <DialogContent className="bg-[#1a1a1a] border-[#333] text-white max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-white text-lg font-bold flex items-center gap-2">
              <Pencil className="w-5 h-5 text-netflix-red" />
              Edit Video
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-2">
            {/* Title */}
            <div className="space-y-1.5">
              <Label htmlFor="edit-title" className="text-netflix-light-grey font-medium text-sm">
                Title <span className="text-netflix-red">*</span>
              </Label>
              <Input
                id="edit-title"
                value={editForm.title}
                onChange={(e) => setEditForm({ ...editForm, title: e.target.value })}
                placeholder="Video title"
                className="bg-[#2a2a2a] border-[#444] text-white placeholder:text-netflix-grey focus:border-netflix-red"
              />
            </div>

            {/* Description */}
            <div className="space-y-1.5">
              <Label htmlFor="edit-description" className="text-netflix-light-grey font-medium text-sm">
                Description
              </Label>
              <Textarea
                id="edit-description"
                value={editForm.description}
                onChange={(e) => setEditForm({ ...editForm, description: e.target.value })}
                placeholder="Video description"
                rows={3}
                className="bg-[#2a2a2a] border-[#444] text-white placeholder:text-netflix-grey focus:border-netflix-red resize-none"
              />
            </div>

            {/* Category */}
            <div className="space-y-1.5">
              <Label htmlFor="edit-category" className="text-netflix-light-grey font-medium text-sm">
                Category
              </Label>
              <select
                id="edit-category"
                value={editForm.category}
                onChange={(e) => setEditForm({ ...editForm, category: e.target.value })}
                className="w-full bg-[#2a2a2a] border border-[#444] text-white rounded-md px-3 py-2 text-sm focus:outline-none focus:border-netflix-red transition-colors"
              >
                {CATEGORIES.map((cat) => (
                  <option key={cat} value={cat} className="bg-[#2a2a2a]">
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            {/* Thumbnail URL */}
            <div className="space-y-1.5">
              <Label htmlFor="edit-thumbnail" className="text-netflix-light-grey font-medium text-sm">
                Thumbnail URL
              </Label>
              <Input
                id="edit-thumbnail"
                value={editForm.thumbnailUrl}
                onChange={(e) => setEditForm({ ...editForm, thumbnailUrl: e.target.value })}
                placeholder="https://... or leave blank"
                className="bg-[#2a2a2a] border-[#444] text-white placeholder:text-netflix-grey focus:border-netflix-red"
              />
              <p className="text-netflix-grey/60 text-xs">
                Or use the{' '}
                <button
                  type="button"
                  onClick={() => {
                    if (editingVideo) {
                      closeEdit();
                      navigate({ to: '/admin/thumbnail/$videoId', params: { videoId: editingVideo.id } });
                    }
                  }}
                  className="text-amber-400 hover:underline"
                >
                  Set Thumbnail
                </button>{' '}
                tool to capture a frame from the video.
              </p>
            </div>
          </div>

          <DialogFooter className="gap-2">
            <DialogClose asChild>
              <Button
                variant="outline"
                className="bg-transparent border-[#444] text-netflix-light-grey hover:bg-[#333] hover:text-white"
              >
                <X className="w-4 h-4 mr-1.5" />
                Cancel
              </Button>
            </DialogClose>
            <Button
              onClick={handleSaveEdit}
              disabled={updateMetadata.isPending || !editForm.title.trim()}
              className="bg-netflix-red hover:bg-netflix-red-hover text-white border-0"
            >
              {updateMetadata.isPending ? (
                <Loader2 className="w-4 h-4 mr-1.5 animate-spin" />
              ) : (
                <Check className="w-4 h-4 mr-1.5" />
              )}
              {updateMetadata.isPending ? 'Saving...' : 'Save Changes'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
