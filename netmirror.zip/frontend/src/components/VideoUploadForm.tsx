import { useState, useRef } from 'react';
import { useNavigate } from '@tanstack/react-router';
import { ExternalBlob } from '../backend';
import { useUploadVideo } from '../hooks/useQueries';
import { Upload, Film, X, AlertCircle } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { toast } from 'sonner';

// 512KB per chunk — safely within ICP's 2MB inter-canister message limit
const CHUNK_SIZE = 512 * 1024;
const MAX_FILE_SIZE = 2 * 1024 * 1024 * 1024; // 2GB

const CATEGORIES = [
  'Action', 'Comedy', 'Drama', 'Horror', 'Sci-Fi',
  'Documentary', 'Animation', 'Thriller', 'Romance', 'Other'
];

// Accepted video MIME types — explicit list to ensure MP4 is always accepted
const ACCEPTED_VIDEO_TYPES = [
  'video/mp4',
  'video/quicktime',
  'video/x-msvideo',
  'video/x-matroska',
  'video/webm',
  'video/ogg',
  'video/mpeg',
  'video/3gpp',
];

interface FormState {
  title: string;
  description: string;
  category: string;
}

export default function VideoUploadForm() {
  const navigate = useNavigate();
  const [form, setForm] = useState<FormState>({
    title: '',
    description: '',
    category: 'Other',
  });
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [fileError, setFileError] = useState<string | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const uploadVideo = useUploadVideo();

  const isValidVideoFile = (file: File): boolean => {
    // Accept by MIME type (primary check)
    if (ACCEPTED_VIDEO_TYPES.includes(file.type)) return true;
    // Accept by extension as fallback (some browsers report empty MIME for MP4)
    const ext = file.name.split('.').pop()?.toLowerCase() ?? '';
    return ['mp4', 'mov', 'avi', 'mkv', 'webm', 'ogv', 'mpeg', '3gp', 'm4v'].includes(ext);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    setFileError(null);
    setSelectedFile(null);
    setUploadError(null);

    if (!file) return;

    if (!isValidVideoFile(file)) {
      setFileError('Please select a valid video file (MP4, MOV, AVI, MKV, etc.).');
      return;
    }

    if (file.size > MAX_FILE_SIZE) {
      setFileError(
        `File size exceeds 2GB limit. Your file is ${(file.size / 1024 ** 3).toFixed(2)} GB.`
      );
      return;
    }

    setSelectedFile(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFile || !form.title.trim() || isUploading) return;

    setIsUploading(true);
    setUploadProgress(0);
    setUploadError(null);

    try {
      const videoId = `video_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;

      // Placeholder thumbnail blob — admin will set the real thumbnail on the next page
      const thumbnailBlob = ExternalBlob.fromURL(
        '/assets/generated/thumbnail-placeholder.dim_400x225.png'
      );

      // Pass the raw File — chunks are read one at a time inside useUploadVideo
      // to avoid loading the entire file into memory (critical for 2GB files)
      const uploadedId = await uploadVideo.mutateAsync({
        id: videoId,
        title: form.title.trim(),
        description: form.description.trim(),
        thumbnail: thumbnailBlob,
        thumbnailUrl: '/assets/generated/thumbnail-placeholder.dim_400x225.png',
        category: form.category,
        file: selectedFile,
        onProgress: (pct) => setUploadProgress(pct),
      });

      toast.success(`"${form.title}" uploaded! Now select a thumbnail.`);

      // Redirect to thumbnail selection page
      navigate({
        to: '/admin/thumbnail/$videoId',
        params: { videoId: uploadedId ?? videoId },
      });
    } catch (err: unknown) {
      setIsUploading(false);
      const raw = err instanceof Error ? err.message : String(err);
      // Surface the backend error message clearly
      const message = raw.includes('Unauthorized')
        ? 'Unauthorized: Only admins can upload videos. Please ensure you are logged in with the admin account.'
        : raw || 'Upload failed. Please try again.';
      setUploadError(message);
      toast.error(message);
    }
  };

  const clearFile = () => {
    setSelectedFile(null);
    setFileError(null);
    setUploadError(null);
    setIsUploading(false);
    setUploadProgress(0);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const totalChunks = selectedFile ? Math.ceil(selectedFile.size / CHUNK_SIZE) : 0;

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      {/* Title */}
      <div className="space-y-1.5">
        <Label htmlFor="title" className="text-netflix-light-grey font-medium">
          Title <span className="text-netflix-red">*</span>
        </Label>
        <Input
          id="title"
          value={form.title}
          onChange={(e) => setForm({ ...form, title: e.target.value })}
          placeholder="Enter video title"
          required
          disabled={isUploading}
          className="bg-[#2a2a2a] border-[#444] text-white placeholder:text-netflix-grey focus:border-netflix-red"
        />
      </div>

      {/* Description */}
      <div className="space-y-1.5">
        <Label htmlFor="description" className="text-netflix-light-grey font-medium">
          Description
        </Label>
        <Textarea
          id="description"
          value={form.description}
          onChange={(e) => setForm({ ...form, description: e.target.value })}
          placeholder="Enter video description"
          rows={3}
          disabled={isUploading}
          className="bg-[#2a2a2a] border-[#444] text-white placeholder:text-netflix-grey focus:border-netflix-red resize-none"
        />
      </div>

      {/* Category */}
      <div className="space-y-1.5">
        <Label htmlFor="category" className="text-netflix-light-grey font-medium">
          Category
        </Label>
        <select
          id="category"
          value={form.category}
          onChange={(e) => setForm({ ...form, category: e.target.value })}
          disabled={isUploading}
          className="w-full bg-[#2a2a2a] border border-[#444] text-white rounded-md px-3 py-2 text-sm focus:outline-none focus:border-netflix-red transition-colors"
        >
          {CATEGORIES.map((cat) => (
            <option key={cat} value={cat} className="bg-[#2a2a2a]">
              {cat}
            </option>
          ))}
        </select>
      </div>

      {/* File Picker */}
      <div className="space-y-1.5">
        <Label className="text-netflix-light-grey font-medium">
          Video File <span className="text-netflix-red">*</span>
        </Label>

        {!selectedFile ? (
          <div
            onClick={() => !isUploading && fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-all duration-200 ${
              fileError
                ? 'border-netflix-red/60 bg-netflix-red/5'
                : 'border-[#444] hover:border-netflix-red/60 hover:bg-netflix-red/5'
            }`}
          >
            <Film className="w-10 h-10 text-netflix-grey mx-auto mb-3" />
            <p className="text-white font-medium mb-1">Click to select video</p>
            <p className="text-netflix-grey text-sm">MP4, MOV, AVI, MKV — Max 2GB</p>
            {fileError && (
              <div className="mt-3 flex items-center gap-2 text-netflix-red text-sm justify-center">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                {fileError}
              </div>
            )}
          </div>
        ) : (
          <div className="bg-[#2a2a2a] border border-[#444] rounded-lg p-4 flex items-center gap-3">
            <div className="w-10 h-10 bg-netflix-red/20 rounded-lg flex items-center justify-center flex-shrink-0">
              <Film className="w-5 h-5 text-netflix-red" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-white text-sm font-medium truncate">{selectedFile.name}</p>
              <p className="text-netflix-grey text-xs">
                {selectedFile.size >= 1024 ** 3
                  ? `${(selectedFile.size / 1024 ** 3).toFixed(2)} GB`
                  : `${(selectedFile.size / 1024 ** 2).toFixed(1)} MB`}
                {' · '}
                {totalChunks.toLocaleString()} chunks
              </p>
            </div>
            {!isUploading && (
              <button
                type="button"
                onClick={clearFile}
                className="text-netflix-grey hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            )}
          </div>
        )}

        {/* Hidden file input — explicit accept list ensures MP4 is always accepted */}
        <input
          ref={fileInputRef}
          type="file"
          accept="video/mp4,video/quicktime,video/x-msvideo,video/x-matroska,video/webm,video/*,.mp4,.mov,.avi,.mkv,.webm,.m4v"
          onChange={handleFileChange}
          className="hidden"
        />
      </div>

      {/* Upload Progress */}
      {isUploading && (
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-netflix-light-grey">
              Uploading... {uploadProgress}%
            </span>
            <span className="text-netflix-grey text-xs">
              {selectedFile && `${totalChunks.toLocaleString()} chunks`}
            </span>
          </div>
          <Progress value={uploadProgress} className="h-2 bg-[#333]" />
          <p className="text-netflix-grey text-xs text-center">
            Large files may take several minutes — please keep this tab open
          </p>
        </div>
      )}

      {/* Upload Error */}
      {!isUploading && uploadError && (
        <div className="flex items-start gap-2 text-netflix-red text-sm bg-netflix-red/10 border border-netflix-red/30 rounded-lg p-3">
          <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
          <span>{uploadError}</span>
        </div>
      )}

      {/* Submit */}
      <Button
        type="submit"
        disabled={!selectedFile || !form.title.trim() || isUploading}
        className="w-full bg-netflix-red hover:bg-netflix-red-hover text-white font-bold py-3 rounded transition-all duration-200 disabled:opacity-50"
      >
        {isUploading ? (
          <span className="flex items-center gap-2">
            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            Uploading {uploadProgress}%...
          </span>
        ) : (
          <span className="flex items-center gap-2">
            <Upload className="w-4 h-4" />
            Upload Video
          </span>
        )}
      </Button>
    </form>
  );
}
