import { useEffect } from 'react';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { Play, Tv, Download, Users, Shield } from 'lucide-react';
import { useRouter } from '@tanstack/react-router';

export default function LoginScreen() {
  const { login, isLoggingIn, identity } = useInternetIdentity();
  const router = useRouter();

  // Redirect to home page after successful login
  useEffect(() => {
    if (identity) {
      router.navigate({ to: '/' });
    }
  }, [identity, router]);

  return (
    <div className="min-h-screen bg-netflix-black relative overflow-hidden flex flex-col">
      {/* Background hero image */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-20"
        style={{ backgroundImage: "url('/assets/generated/hero-banner.dim_1920x600.png')" }}
      />
      {/* Gradient overlays */}
      <div className="absolute inset-0 bg-gradient-to-b from-netflix-black/70 via-netflix-black/50 to-netflix-black" />
      <div className="absolute inset-0 bg-gradient-to-r from-netflix-black/60 via-transparent to-netflix-black/60" />

      {/* Header */}
      <header className="relative z-10 flex items-center justify-between px-8 py-6 md:px-16">
        <span
          aria-label="NetMirror"
          className="text-3xl md:text-4xl font-black text-netflix-red tracking-tight select-none"
        >
          NetMirror
        </span>
        <button
          onClick={login}
          disabled={isLoggingIn}
          className="bg-netflix-red hover:bg-netflix-red-hover text-white font-semibold px-6 py-2.5 rounded-lg transition-all duration-200 disabled:opacity-60 disabled:cursor-not-allowed flex items-center gap-2 text-sm"
        >
          {isLoggingIn ? (
            <>
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              Signing in...
            </>
          ) : (
            'Sign In'
          )}
        </button>
      </header>

      {/* Hero Content */}
      <main className="relative z-10 flex-1 flex flex-col items-center justify-center text-center px-6 py-16 md:py-24">
        {/* Logo / Brand card */}
        <div className="mb-8 flex flex-col items-center">
          <div className="w-20 h-20 bg-netflix-red/20 border-2 border-netflix-red/40 rounded-2xl flex items-center justify-center mb-5 shadow-netflix">
            <Play className="w-10 h-10 text-netflix-red fill-netflix-red" />
          </div>
          <h1 className="text-5xl md:text-7xl font-black text-white mb-3 leading-none tracking-tight">
            Net<span className="text-netflix-red">Mirror</span>
          </h1>
          <p className="text-netflix-light-grey text-lg md:text-xl font-light tracking-wide">
            Your personal streaming universe
          </p>
        </div>

        <div className="max-w-xl mx-auto mb-10">
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-3">
            Unlimited movies, TV shows and more
          </h2>
          <p className="text-netflix-grey text-base md:text-lg">
            Sign in to start streaming. Watch anywhere, anytime.
          </p>
        </div>

        {/* CTA Button */}
        <button
          onClick={login}
          disabled={isLoggingIn}
          className="bg-netflix-red hover:bg-netflix-red-hover text-white font-bold text-lg px-12 py-4 rounded-xl flex items-center gap-3 transition-all duration-200 disabled:opacity-60 disabled:cursor-not-allowed shadow-netflix hover:shadow-netflix hover:scale-105 active:scale-95 mb-4"
        >
          {isLoggingIn ? (
            <>
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              Signing in...
            </>
          ) : (
            <>
              <Play className="w-5 h-5 fill-white" />
              Get Started — Sign In
            </>
          )}
        </button>
        <p className="text-netflix-grey text-sm">
          Secure sign-in powered by{' '}
          <span className="text-netflix-light-grey font-medium">Internet Identity</span>
        </p>
      </main>

      {/* Divider */}
      <div className="relative z-10 border-t border-netflix-dark/60 mx-0" />

      {/* Features */}
      <section className="relative z-10 py-14 px-6 md:px-16 bg-netflix-black/80">
        <div className="max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="flex flex-col items-center text-center gap-3 p-5 bg-[#1a1a1a] rounded-xl border border-[#2e2e2e]">
            <div className="w-12 h-12 bg-netflix-red/20 rounded-xl flex items-center justify-center">
              <Tv className="w-6 h-6 text-netflix-red" />
            </div>
            <h3 className="text-base font-bold text-white">Watch Everywhere</h3>
            <p className="text-netflix-grey text-xs leading-relaxed">
              Stream on your phone, tablet, laptop, and TV.
            </p>
          </div>
          <div className="flex flex-col items-center text-center gap-3 p-5 bg-[#1a1a1a] rounded-xl border border-[#2e2e2e]">
            <div className="w-12 h-12 bg-netflix-red/20 rounded-xl flex items-center justify-center">
              <Play className="w-6 h-6 text-netflix-red" />
            </div>
            <h3 className="text-base font-bold text-white">HD Quality</h3>
            <p className="text-netflix-grey text-xs leading-relaxed">
              Enjoy high-definition video with smooth playback.
            </p>
          </div>
          <div className="flex flex-col items-center text-center gap-3 p-5 bg-[#1a1a1a] rounded-xl border border-[#2e2e2e]">
            <div className="w-12 h-12 bg-netflix-red/20 rounded-xl flex items-center justify-center">
              <Users className="w-6 h-6 text-netflix-red" />
            </div>
            <h3 className="text-base font-bold text-white">For Everyone</h3>
            <p className="text-netflix-grey text-xs leading-relaxed">
              Curated content for all tastes and preferences.
            </p>
          </div>
          <div className="flex flex-col items-center text-center gap-3 p-5 bg-[#1a1a1a] rounded-xl border border-[#2e2e2e]">
            <div className="w-12 h-12 bg-netflix-red/20 rounded-xl flex items-center justify-center">
              <Shield className="w-6 h-6 text-netflix-red" />
            </div>
            <h3 className="text-base font-bold text-white">Secure & Private</h3>
            <p className="text-netflix-grey text-xs leading-relaxed">
              Decentralized identity — you own your account.
            </p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative z-10 border-t border-netflix-dark/60 py-6 px-6 md:px-16 text-center bg-netflix-black">
        <p className="text-netflix-grey text-sm">
          © {new Date().getFullYear()} NetMirror. Built with ❤️ using{' '}
          <a
            href={`https://caffeine.ai/?utm_source=Caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(window.location.hostname || 'netmirror')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="text-netflix-red hover:underline"
          >
            caffeine.ai
          </a>
        </p>
      </footer>
    </div>
  );
}
