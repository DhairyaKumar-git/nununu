import type { Principal } from "@icp-sdk/core/principal";
export interface Some<T> {
    __kind__: "Some";
    value: T;
}
export interface None {
    __kind__: "None";
}
export type Option<T> = Some<T> | None;
export class ExternalBlob {
    getBytes(): Promise<Uint8Array<ArrayBuffer>>;
    getDirectURL(): string;
    static fromURL(url: string): ExternalBlob;
    static fromBytes(blob: Uint8Array<ArrayBuffer>): ExternalBlob;
    withUploadProgress(onProgress: (percentage: number) => void): ExternalBlob;
}
export type Time = bigint;
export interface VideoMetadata {
    id: string;
    title: string;
    thumbnail: ExternalBlob;
    thumbnailUrl: string;
    description: string;
    category: string;
    uploadDate: Time;
}
export interface UserProfile {
    bio: string;
    name: string;
}
export enum UserRole {
    admin = "admin",
    user = "user",
    guest = "guest"
}
export interface backendInterface {
    addToLibrary(videoId: string): Promise<void>;
    assignCallerUserRole(user: Principal, role: UserRole): Promise<void>;
    deleteVideo(videoId: string): Promise<void>;
    getAllVideosMetadata(): Promise<Array<VideoMetadata>>;
    getCallerUserProfile(): Promise<UserProfile | null>;
    getCallerUserRole(): Promise<UserRole>;
    getMyLibrary(): Promise<Array<string>>;
    getNumberOfVideos(): Promise<bigint>;
    getUserProfile(user: Principal): Promise<UserProfile | null>;
    getUsername(): Promise<string | null>;
    getVideoChunk(videoId: string, chunkIndex: bigint): Promise<ExternalBlob>;
    getVideoChunks(videoId: string): Promise<Array<ExternalBlob>>;
    getVideoMetadata(videoId: string): Promise<VideoMetadata>;
    isAdmin(): Promise<boolean>;
    isCallerAdmin(): Promise<boolean>;
    removeFromLibrary(videoId: string): Promise<void>;
    saveCallerUserProfile(profile: UserProfile): Promise<void>;
    setUsername(name: string): Promise<void>;
    updateVideoMetadata(videoId: string, title: string, description: string, category: string, thumbnailUrl: string): Promise<boolean>;
    updateVideoThumbnail(videoId: string, thumbnailDataUrl: string): Promise<boolean>;
    uploadInitialVideoChunk(id: string, title: string, description: string, thumbnail: ExternalBlob, thumbnailUrl: string, category: string, totalChunks: bigint, chunkIndex: bigint, chunk: ExternalBlob): Promise<void>;
    uploadVideoChunk(videoId: string, chunkIndex: bigint, chunk: ExternalBlob): Promise<void>;
}
