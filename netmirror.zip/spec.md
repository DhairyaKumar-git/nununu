# Specification

## Summary
**Goal:** Add search, fix auto-play, add admin video editing, improve UI on login and dashboard, remove footer credit, and display a friendly user ID instead of the full principal.

**Planned changes:**
- Add a search bar to the Navbar and ViewerHome that filters video cards in real time by title or category, with an empty-state message when no results are found
- Disable auto-play on the VideoPlayer page so users must explicitly press play to start a video
- Add an Edit button to each video row in the admin management list that opens a pre-filled form/modal for updating title, description, category, and thumbnail URL, backed by a new admin-only `updateVideoMetadata` backend function
- Add a "Set Thumbnail" button to each video row in the admin management list that navigates to the existing thumbnail-selection page
- Redesign the Login page with a centered card layout, NetMirror logo, clear headline/subtitle, and a prominently styled Internet Identity sign-in button using the red accent color
- Redesign the Admin Dashboard with a clear header showing the admin's username, improved tab navigation, better-grouped upload form, and a cleaner video management list layout
- Remove the "DhairyaKumar" red footer credit from ViewerHome
- Replace the full ICP principal string in the Navbar dropdown (and any other profile display areas) with a short deterministic friendly user ID (e.g., "User #12345")

**User-visible outcome:** Users can search for videos by title or category, videos no longer auto-play on navigation, admins can edit video metadata and set thumbnails directly from the dashboard, the login and admin dashboard pages have a polished look, the footer credit is gone, and users see a friendly short ID instead of their full principal string.
